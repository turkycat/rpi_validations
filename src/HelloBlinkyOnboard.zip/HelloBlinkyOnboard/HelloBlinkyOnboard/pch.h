#pragma once

#include <ppltasks.h>
#include <arduino.h>
#include <pinnumbers.h>
